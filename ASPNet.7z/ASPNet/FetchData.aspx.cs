using System;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;

public partial class FetchData : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            FetchDataFromDatabase();
        }
    }

    private void FetchDataFromDatabase()
    {
        // Connection string from Web.config file
        string connectionString = ConfigurationManager.ConnectionStrings["YourConnectionStringName"].ConnectionString;

        using (SqlConnection con = new SqlConnection(connectionString))
        {
            // SQL query to fetch data
            string query = "SELECT * FROM tWords";

            using (SqlCommand cmd = new SqlCommand(query, con))
            {
                using (SqlDataAdapter sda = new SqlDataAdapter(cmd))
                {
                    DataTable dt = new DataTable();
                    sda.Fill(dt);
                    GridView1.DataSource = dt;
                    GridView1.DataBind();
                }
            }
        }
    }
}
